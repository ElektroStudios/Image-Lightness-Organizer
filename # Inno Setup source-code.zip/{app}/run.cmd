@ECHO OFF

SET "DIRECTORY=%~f1"

IF DEFINED DIRECTORY (
    "%~dp0Image_Lightness_Organizer.exe" "%DIRECTORY%"
) ELSE (
    "%~dp0Image_Lightness_Organizer.exe"
)

PAUSE